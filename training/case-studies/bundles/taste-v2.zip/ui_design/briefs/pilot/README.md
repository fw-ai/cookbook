# Pilot briefs (24)

Seven families, eight briefs with generated-v1 assets, fixed fictional public content, and a mix of disclosures, filtering, price updates, a timetable switch, and a units toggle. The JSON files are authoritative. See [data provenance](DATA_SOURCES.md).

Required facts can use normal HTML structure and whitespace. Initial facts must be visible before interaction; deferred facts are checked in the specified state. Supplied collections must preserve every row and field.

| Brief | Family | Images | Interaction |
| --- | --- | --- | --- |
| [annual-report-summary](annual-report-summary.json) | editorial | 0 | disclosure |
| [bakery-subscription](bakery-subscription.json) | local | 1 | state sequence |
| [bike-repair](bike-repair.json) | local | 0 | disclosure |
| [climbing-gym](climbing-gym.json) | local | 0 | disclosure |
| [coffee-roaster](coffee-roaster.json) | commerce | 1 | state sequence |
| [community-garden](community-garden.json) | civic | 1 | disclosure |
| [developer-tool](developer-tool.json) | technical | 0 | disclosure |
| [dog-daycare](dog-daycare.json) | local | 1 | disclosure |
| [ferry-timetable](ferry-timetable.json) | timetable | 0 | state sequence |
| [furniture-maker](furniture-maker.json) | commerce | 1 | disclosure |
| [library-hours](library-hours.json) | timetable | 0 | disclosure |
| [long-essay-landing](long-essay-landing.json) | editorial | 0 | disclosure |
| [mechanical-keyboard](mechanical-keyboard.json) | technical | 0 | state sequence |
| [museum-exhibition](museum-exhibition.json) | dense | 1 | disclosure |
| [music-festival](music-festival.json) | dense | 0 | disclosure |
| [plant-shop](plant-shop.json) | commerce | 1 | state sequence |
| [print-shop-rebrand](print-shop-rebrand.json) | editorial | 0 | disclosure |
| [ramen-counter](ramen-counter.json) | local | 1 | disclosure |
| [recycling-guide](recycling-guide.json) | civic | 0 | disclosure |
| [science-lecture-series](science-lecture-series.json) | dense | 0 | disclosure |
| [scientific-instrument](scientific-instrument.json) | technical | 0 | disclosure |
| [swim-school](swim-school.json) | timetable | 0 | disclosure |
| [theatre-season](theatre-season.json) | dense | 0 | disclosure |
| [weather-station](weather-station.json) | technical | 0 | disclosure |

## annual-report-summary

A river conservation charity publishes a one-page summary of its annual report: four numbers, three stories, one ask. Readers are donors who will not open the PDF. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Tidewater Trust; 2,400 volunteers; 38 km of bank restored; $1.2M raised; Donate; Read the full report; Year ending March

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: 14 species returned

Brand: Serious, generous, no stock river photos. Numbers are the hero.

### Supplied stories (3 rows)

| title | summary |
| --- | --- |
| A shared riverbank | Volunteers restored planting along the lower bank. |
| Wildlife returns | Monitoring recorded the return of local species. |
| A new generation | Schools joined weekend river surveys. |

## bakery-subscription

Crumb is a sourdough bakery that delivers a weekly loaf box by bicycle within 3 miles. Three box sizes. Customers choose a delivery day. The page must explain the subscription clearly enough that someone subscribes without emailing a question. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Crumb; One loaf $9 a week; Two loaves $16 a week; Family box $28 a week; Delivery Tuesday, Thursday or Saturday; Pause or cancel any time; Within 3 miles of the bakery on Fenwick Street

Interaction: Native select data-testid="box-size" with values one, two, family updates data-testid="weekly-price" to $9, $16, $28 respectively. Initially one.

Brand: Warm, flour-dusted, not twee. No illustrations of bread unless drawn in CSS or SVG. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Rustic sourdough loaf and cut slice in soft morning window light.](../../assets/pilot/bakery-subscription-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

## bike-repair

Spoke & Sprocket is a one-person bicycle repair workshop. Fixed-price services, same-week turnaround, drop-off by appointment. The owner wants fewer phone calls asking what things cost. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Spoke & Sprocket; Puncture $15; Full service $85; Brake bleed $45; Drop-off Monday to Friday 8am to 6pm; Book by text to 555-0147

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Wheel true $25

Brand: Workshop honesty: grease, steel, hand-lettered signs. No stock imagery.

## climbing-gym

Granite Peak is a new climbing gym opening in a converted cannery on Pier 4 in a mid-sized port city. It has 40-foot lead walls, a large bouldering area, a training mezzanine and a cafe. The audience is adults 20 to 45, from first-timers to competitive climbers. The tone is confident and physical, not corporate. The page should make a first-timer feel welcome and make an experienced climber want to see the walls. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Granite Peak; Pier 4; Day pass $22; Membership $89 a month; Intro class every Saturday 10am

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: 6am to 11pm

Brand: No brand colors given; choose a palette that fits a cannery turned gym. No stock-photo placeholders: if an image is not provided, do not invent one.

## coffee-roaster

Northlight roasts three single-origin coffees and one blend, sold by the 250 g bag, with a subscription option. The page must make choosing a coffee easy for someone who does not know tasting notes. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Northlight; 250 g bag $14; Subscription $12 a bag; Ethiopia; Colombia; Guatemala; House blend; Roasted Mondays, shipped Tuesdays

Interaction: A native select data-testid="purchase-mode" with values once and subscription updates data-testid="bag-price" from $14 to $12 per 250 g bag. Initially once.

Brand: Warm, specific, no latte art. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Roasted beans and black filter coffee in handmade ceramics on oak.](../../assets/pilot/coffee-roaster-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

### Supplied coffees (4 rows)

| coffee | notes |
| --- | --- |
| Ethiopia | Floral and citrus |
| Colombia | Caramel and apple |
| Guatemala | Cocoa and toasted nuts |
| House blend | Chocolate and brown sugar |

## community-garden

Elm Street Community Garden has 40 plots, a waiting list, open days and rules. The page must explain how to get a plot and what is expected. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Elm Street Community Garden; 40 plots; Waiting list; $35 a year; Open day first Sunday; Water on site; Join the list

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: No pesticides

Brand: Hand-made, hopeful, no cartoon vegetables. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Raised vegetable beds, gravel path and wooden shed in an urban garden.](../../assets/pilot/community-garden-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

## developer-tool

Ledgerline is a command-line tool that records every shell command you run with its working directory and exit code, searchable later. Single binary, local only, no account. The page is for developers who distrust marketing. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Single binary; Local only, no account; ledgerline search; MIT licence; macOS and Linux; Free

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: brew install ledgerline

Brand: Terminal honesty: monospace where it earns it, no hero gradient, no fake dashboard screenshots.

## dog-daycare

Muddy Paws is a dog daycare on a farm 20 minutes from the city, with a van pickup route. Dogs are assessed before their first day. The page is for anxious first-time owners. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Muddy Paws; Full day $42; Half day $28; Assessment visit free; Open Monday to Friday 7am to 7pm; Rainy days: barn play

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Van pickup $8 each way

Brand: Reassuring and outdoorsy. No cartoon dogs. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Two dogs playing on a grassy farm paddock with a barn behind them.](../../assets/pilot/dog-daycare-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

## ferry-timetable

The Pelican ferry runs between Harbour Quay and Oyster Point, 14 departures a day from Harbour Quay in summer, 8 in winter, 25 minutes per crossing. The page is the timetable people check on the pier. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Pelican Ferry; Harbour Quay; Oyster Point; 25 minutes; Adult single $6; Return $10; Bikes free; Summer timetable 1 April to 30 September; First sailing 6:40am; Last sailing 9:15pm

Interaction: Show summer departures initially. Buttons data-testid="winter" and "summer" switch between content-summer and content-winter. Show the supplied departures from Harbour Quay only; do not invent return departures.

Brand: Legible at arm's length in sunlight. No decoration that competes with the times.

### Supplied summer (14 rows)

| departure |
| --- |
| 6:40am |
| 7:30am |
| 8:20am |
| 9:10am |
| 10am |
| 11am |
| 12pm |
| 1pm |
| 2pm |
| 3pm |
| 4pm |
| 5pm |
| 7pm |
| 9:15pm |

### Supplied winter (8 rows)

| departure |
| --- |
| 7am |
| 8am |
| 9am |
| 11am |
| 1pm |
| 3pm |
| 5pm |
| 7pm |

## furniture-maker

Bowline makes four pieces of furniture to order in oak or ash: a bench, a stool, a side table, a shelf. Lead time six weeks. The page is a catalogue with dimensions and prices. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Bowline; Bench $640; Stool $220; Shelf $290; Oak or ash; Six weeks; Made in the workshop on Dock Street

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Side table $380

Brand: Quiet, material, exact. Dimensions in cm. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Oak bench and ash side table in a quiet naturally lit room.](../../assets/pilot/furniture-maker-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

### Supplied pieces (4 rows)

| piece | price | dimensions |
| --- | --- | --- |
| Bench | $640 | 120 × 35 × 45 cm |
| Stool | $220 | 35 × 35 × 45 cm |
| Side table | $380 | 45 × 45 × 50 cm |
| Shelf | $290 | 80 × 20 × 25 cm |

## library-hours

Westgate Library has three branches with different hours, a mobile library with a weekly route, and a study room that must be booked. The page is the one the council links to. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Westgate Library; Central branch; Northfield branch; Riverside branch; Mobile library; Study room booking; Free membership; Closed public holidays

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Mobile route: Monday Oak Square; Tuesday Northfield; Wednesday Riverside; Thursday Market Lane; Friday Central

Brand: Civic, accessible, large type.

### Supplied branches (3 rows)

| branch | hours |
| --- | --- |
| Central branch | Monday to Saturday 9am to 7pm |
| Northfield branch | Tuesday to Saturday 10am to 6pm |
| Riverside branch | Monday to Friday 10am to 5pm |

## long-essay-landing

An independent magazine is publishing a 9,000-word essay on the history of the lighthouse keepers' union. The page is the essay's front door: title, standfirst, author, reading time, and the first three paragraphs, then a continue control. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: By Ines Maro; Reading time 35 minutes; Continue reading; The Lamp; Issue 12

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: At dawn, the keepers compared their logs before the harbor woke.

Brand: Editorial typography: measure, leading, a drop cap if earned. Write the standfirst and three plausible opening paragraphs. No images.

### Supplied opening (3 rows)

| paragraph |
| --- |
| The lamp was a workplace before it became a symbol. Its keepers measured the night in oil, weather, and hours of wakefulness. |
| Along the coast, each station kept a separate ledger. Those quiet records eventually became the basis for a shared demand: safer shifts and reliable pay. |
| This essay follows the fictional keepers who learned to turn isolated complaints into a common voice. |

## mechanical-keyboard

Keel is a 65% mechanical keyboard sold as a kit: case, plate, PCB; switches and keycaps sold separately. The page must make the kit's contents and compatibility unambiguous. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Keel 65; Kit $149; Aluminium case; Hot-swap PCB; Ships without switches or keycaps; MX-compatible; USB-C; Ships in 2 to 3 weeks

Interaction: A button data-testid="units" toggles data-testid="dimensions" between 32 × 12 cm and 12.6 × 4.7 in. Initially metric.

Brand: Enthusiast precision; type and spacing do the work. No product photos provided.

## museum-exhibition

The city museum is staging 'Glass Houses', an exhibition of 60 architectural models and drawings from 1920 to 1975, running fourteen weeks. The page must carry the practical facts and a sense of the material, and must work as the thing a visitor reads on their phone outside the building. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Glass Houses; 14 March to 21 June; Adults $18; Concessions $12; Under 16 free; Tuesday to Sunday 10am to 6pm; Gallery 3, second floor; Curator talk Saturdays 2pm

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Late opening Thursday until 9pm

Brand: Institutional but not cold. Greyscale plus one colour. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Mid-century modern house scale model displayed in a quiet gallery.](../../assets/pilot/museum-exhibition-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

## music-festival

Low Tide is a two-day music festival on a shingle beach with three stages and 28 acts. The lineup is the page. Camping is separate. The audience already knows the genre; the page should feel like the poster. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Low Tide; Saturday 9 and Sunday 10 August; Weekend ticket $140; Day ticket $85; Camping $40 per tent; Harbour Stage; Shingle Stage; Gates 11am; Last act 11pm

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Hut Stage

Brand: Poster energy: big type, a system, no gradients.

### Supplied lineup (28 rows)

| act | day | stage | time |
| --- | --- | --- | --- |
| Salt Index | Saturday | Harbour Stage | 12:00 |
| Paper Harbor | Saturday | Shingle Stage | 12:30 |
| Low Lantern | Saturday | Hut Stage | 13:00 |
| Brass Current | Saturday | Harbour Stage | 14:00 |
| Night Buoy | Saturday | Shingle Stage | 14:30 |
| Tidal Rooms | Saturday | Hut Stage | 15:00 |
| Silver Kelp | Saturday | Harbour Stage | 16:00 |
| North Window | Saturday | Shingle Stage | 16:30 |
| Quiet Engine | Saturday | Hut Stage | 17:00 |
| Ferry Lights | Saturday | Harbour Stage | 18:00 |
| Dune Radio | Saturday | Shingle Stage | 19:00 |
| Glass Current | Saturday | Hut Stage | 20:00 |
| Copper Hours | Saturday | Harbour Stage | 21:00 |
| Last Beacon | Saturday | Shingle Stage | 23:00 |
| Foam Atlas | Sunday | Hut Stage | 12:00 |
| Small Weather | Sunday | Harbour Stage | 12:30 |
| Night Orchard | Sunday | Shingle Stage | 13:00 |
| Breakwater Club | Sunday | Hut Stage | 14:00 |
| Paper Moonrise | Sunday | Harbour Stage | 14:30 |
| West Pier | Sunday | Shingle Stage | 15:00 |
| Slow Circuit | Sunday | Hut Stage | 16:00 |
| Bright Shingle | Sunday | Harbour Stage | 16:30 |
| Open Water | Sunday | Shingle Stage | 17:00 |
| Moss Signal | Sunday | Hut Stage | 18:00 |
| Long Horizon | Sunday | Harbour Stage | 19:00 |
| Drift Choir | Sunday | Shingle Stage | 20:00 |
| Warm Static | Sunday | Hut Stage | 21:00 |
| Final Lantern | Sunday | Harbour Stage | 23:00 |

## plant-shop

Fernery sells six houseplants online with care levels and ships bare-root in paper. The page lists the six with price and light needs and explains shipping. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Fernery; Six plants; Low light; Bright indirect; Ships bare-root; Free shipping over $60; Arrives in 3 days; Pothos $18; Monstera $34

Interaction: Show all six supplied plants initially. A native select data-testid="light-filter" with values all, low, bright filters visible cards in content-plants. Hidden plants must leave the visible results.

Brand: Green but not a jungle cliche. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Monstera and pothos in terracotta and ceramic pots against warm plaster.](../../assets/pilot/plant-shop-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

### Supplied plants (6 rows)

| plant | price | light |
| --- | --- | --- |
| Pothos | $18 | Low light |
| Monstera | $34 | Bright indirect |
| Snake plant | $22 | Low light |
| ZZ plant | $26 | Low light |
| Bird nest fern | $24 | Bright indirect |
| Rubber plant | $30 | Bright indirect |

## print-shop-rebrand

Alder Press is a 60-year-old letterpress print shop moving into digital layout as well. The page is the rebrand announcement to existing clients: what stays, what changes, who to call. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Alder Press; Since 1964; Letterpress and digital; Same workshop on Mill Road; Call Ruth on 555-0122; Quotes within two days

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: New: digital layout and composition

Brand: Ink, paper, impression. Type is the design. No images.

## ramen-counter

Hinode is a twelve-seat ramen counter in a railway arch. One cook, one broth (tonkotsu simmered 18 hours), four bowls on the menu, no reservations, cash or card. It sells out most nights by 8:30. The page is for people deciding whether to queue tonight. Tone: plain, unhurried, a little proud. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Hinode; Arch 14, Stanmore Lane; Shio $16; Shoyu $16; Tonkotsu $18; Tuesday to Sunday 5pm until sold out; No reservations

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Spicy miso $19

Brand: Palette from the arch: brick, steam, a single warm light. Use the supplied generated concept image meaningfully. Include a discreet AI-generated image credit. The image illustrates a fictional brief and is not documentary evidence or a guarantee of exact product dimensions.

Image: [AI-generated concept: Tonkotsu ramen in handmade ceramic on a warm railway-arch counter.](../../assets/pilot/ramen-counter-generated-v1.png). See [prompts and provenance](../../assets/pilot/GENERATED_ASSETS.md).

## recycling-guide

The council's recycling guide: which bin for which material, collection days by zone, and what to do with the eleven things people get wrong. Readers are irritated residents. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Recycling guide; Blue bin; Green bin; Black bin; Zone A: Monday; Zone B: Thursday; Glass to bottle banks; Bulky items by appointment

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: No soft plastics

Brand: Clear, unfussy, high contrast. No icons that need a key.

### Supplied mistakes (11 rows)

| material | instruction |
| --- | --- |
| Glass | Bottle banks |
| Soft plastics | Do not put in household recycling |
| Food scraps | Green bin |
| Clean paper | Blue bin |
| Greasy pizza boxes | Black bin |
| Batteries | Take to collection point |
| Textiles | Textile collection point |
| Paint | Household hazardous-waste collection |
| Electronics | Electronics collection point |
| Broken ceramics | Black bin |
| Furniture | Bulky items by appointment |

## science-lecture-series

A university runs a free public lecture series, eight Thursday evenings, each a different scientist and topic. The page must list all eight with speaker, title and date, and explain how to register. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Thursday Lectures; Free, registration required; 7pm; Lecture Theatre B; Eight evenings; Doors 6:30pm

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Register online or at the door

Brand: Academic clarity.  No photographs.

### Supplied lectures (8 rows)

| speaker | title | date |
| --- | --- | --- |
| Mira Vale | How stars make elements | 7 October 2027 |
| Jon Bell | The hidden life of soil | 14 October 2027 |
| Ada Fen | Why batteries age | 21 October 2027 |
| Niko Reed | Mapping ocean currents | 28 October 2027 |
| Lea Moss | How birds navigate | 4 November 2027 |
| Sam Pike | Mathematics of epidemics | 11 November 2027 |
| Ira Lane | Listening to earthquakes | 18 November 2027 |
| Noor Ash | The chemistry of color | 25 November 2027 |

## scientific-instrument

The Vela 220 is a benchtop spectrophotometer for teaching labs. The page is a product page with a specification table, three use cases and a request-a-quote path. Buyers are lab managers. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Vela 220; Wavelength range 190 to 1100 nm; Photometric accuracy ±0.003 A; Warm-up 15 minutes; Weight 9.5 kg; Two-year warranty; Request a quote

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Bandwidth 1.8 nm

Brand: Precise, calm, credible. No invented certifications. No photographs provided; a line drawing in SVG is acceptable.

## swim-school

Otter Swim School teaches children 3 to 12 in six levels, with term dates and a weekly timetable by level. Parents need to find their child's level and a slot. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Otter Swim School; Six levels; Term $180; Eight weeks; Saturday and Sunday mornings; Level 1: water confidence; Free assessment

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Level 6: 50 metres

Brand: Bright without being babyish.

### Supplied classes (6 rows)

| level | skill | day | time |
| --- | --- | --- | --- |
| Level 1 | water confidence | Saturday | 9am |
| Level 2 | floating | Saturday | 10am |
| Level 3 | kicking | Saturday | 11am |
| Level 4 | front crawl | Sunday | 9am |
| Level 5 | 25 metres | Sunday | 10am |
| Level 6 | 50 metres | Sunday | 11am |

## theatre-season

The Corner Theatre announces a six-play autumn season. Each play has dates, a one-line description and a running time. Subscribers pick any four. The page is read by existing subscribers deciding what to pick. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Corner Theatre; Autumn season; Six plays; Single tickets $34; Previews $20; Box office 555-0199; Running time

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Pick any four $120

Brand: Playbill tradition, modern execution.  No images.

### Supplied plays (6 rows)

| title | dates | description | running_time |
| --- | --- | --- | --- |
| The Last Tram | 1–4 October 2027 | A driver makes one final journey. | 95 minutes |
| Paper Houses | 8–11 October 2027 | Neighbors redraw their boundaries. | 110 minutes |
| Harbor Lights | 15–18 October 2027 | Two siblings reopen a shop. | 85 minutes |
| Small Hours | 22–25 October 2027 | A night shift becomes a reunion. | 100 minutes |
| The Orchard | 29–31 October 2027 | A family debates its inheritance. | 120 minutes |
| After the Rain | 5–8 November 2027 | A town rebuilds its meeting place. | 90 minutes |

## weather-station

Skylark is a home weather station with a rooftop sensor and an indoor display that also publishes to a public map. The page sells the kit and explains the data. This is a fictional benchmark business. Use supplied content without adding testimonials, credentials, or unsupported factual claims.

Initial facts: Skylark; Kit $219; Temperature, humidity, pressure, wind, rain; Battery 18 months; Range 150 m; Public map opt-in; Works offline

Interaction: An accessible disclosure button with data-testid="details-toggle" opens and closes a panel with data-testid="details-panel". The panel starts hidden and contains: Updates every 60 seconds

Brand: Clean instrument aesthetic.
