# Pilot content and image provenance

The business names, prices, schedules, acts, speakers, stories, and product specifications in these JSON files are authored fictional benchmark fixtures. They are supplied openly with this study under CC0 1.0 (https://creativecommons.org/publicdomain/zero/1.0/). They are not scraped customer data or factual claims about real organizations. Every arm receives the identical fixture. Do not invent additional business facts.

Eight briefs now use frozen AI-generated concept images. See [generated asset provenance](../../assets/pilot/GENERATED_ASSETS.md). The earlier Wikimedia Commons reference images remain available as an alternative set. Their individual licenses remain in effect, independently of the fixture dedication. See [image source manifest](../../assets/pilot/sources.json) for source pages, creators, license metadata, download URLs, and SHA-256 hashes. Images are context/reference material, not photos of the fictional businesses. Attribution accompanies the supplied asset description and should appear in the page.

Images are generated or downloaded once and served locally. No image search, live remote fetches, or private assets are needed during generation or rendering. The generated model output is code; images are assets rather than supervised pixel targets.

The fictional text fixture CC0 dedication does not describe the rights status of generated images. Generated image provenance is recorded separately; no Wikimedia photographer credit or CC license is attached to a generated image.
