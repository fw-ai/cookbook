# Pilot image assets

The active set is [generated-v1](GENERATED_ASSETS.md), with exact prompts and hashes. Original public images below are preserved for comparison and historical reproducibility.

# Public pilot image credits

Downloaded October 20, 2026 from Wikimedia Commons. Each image retains the individual license listed below. These are reference photographs, not photographs of the fictional businesses. The JSON manifest retains source metadata and byte hashes. No proprietary assets are included.

## ramen-counter

- File: `ramen-counter.jpg`
- Source: [File:Bowl of shio ramen with pork.jpg](https://commons.wikimedia.org/wiki/File:Bowl_of_shio_ramen_with_pork.jpg)
- Creator: GiveMeMollusks
- License: CC0 (http://creativecommons.org/publicdomain/zero/1.0/deed.en)
- Change: Wikimedia-generated thumbnail; no local image edits.

## bakery-subscription

- File: `bakery-subscription.jpg`
- Source: [File:Sourdough Bread Loaf.jpg](https://commons.wikimedia.org/wiki/File:Sourdough_Bread_Loaf.jpg)
- Creator: Agelaia
- License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0)
- Change: Wikimedia-generated thumbnail; no local image edits.

## dog-daycare

- File: `dog-daycare.jpg`
- Source: [File:Photograph of President Gerald R. Ford's Dog Liberty and Another Golden Retriever Playing in the South Lawn Fountain at the White House - NARA - 7462034.jpg](https://commons.wikimedia.org/wiki/File:Photograph_of_President_Gerald_R._Ford%27s_Dog_Liberty_and_Another_Golden_Retriever_Playing_in_the_South_Lawn_Fountain_at_the_White_House_-_NARA_-_7462034.jpg)
- Creator: 
Unknown authorUnknown author or not provided
- License: Public domain (see the source page and saved metadata)
- Change: Wikimedia-generated thumbnail; no local image edits.

## museum-exhibition

- File: `museum-exhibition.jpg`
- Source: [File:Architectural models on view at the Cooper Hewitt museum.jpg](https://commons.wikimedia.org/wiki/File:Architectural_models_on_view_at_the_Cooper_Hewitt_museum.jpg)
- Creator: D_M_D

- License: CC BY-SA 2.0 (https://creativecommons.org/licenses/by-sa/2.0)
- Change: Wikimedia-generated thumbnail; no local image edits.

## plant-shop

- File: `plant-shop.jpg`
- Source: [File:Macroscopic picture of Monstera Deliciosa.jpg](https://commons.wikimedia.org/wiki/File:Macroscopic_picture_of_Monstera_Deliciosa.jpg)
- Creator: Iva508
- License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0)
- Change: Wikimedia-generated thumbnail; no local image edits.

## coffee-roaster

- File: `coffee-roaster.jpg`
- Source: [File:Roasted coffee beans.jpg](https://commons.wikimedia.org/wiki/File:Roasted_coffee_beans.jpg)
- Creator: MarkSweep
- License: Public domain (see the source page and saved metadata)
- Change: Wikimedia-generated thumbnail; no local image edits.

## furniture-maker

- File: `furniture-maker.jpg`
- Source: [File:Solid wooden chair shaped to an organic form.jpg](https://commons.wikimedia.org/wiki/File:Solid_wooden_chair_shaped_to_an_organic_form.jpg)
- Creator: KaiKemmann
- License: CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0)
- Change: Wikimedia-generated thumbnail; no local image edits.

## community-garden

- File: `community-garden.jpg`
- Source: [File:Community vegetable garden in Devonport Park - geograph.org.uk - 7612121.jpg](https://commons.wikimedia.org/wiki/File:Community_vegetable_garden_in_Devonport_Park_-_geograph.org.uk_-_7612121.jpg)
- Creator: Stephen Craven 
- License: CC BY-SA 2.0 (https://creativecommons.org/licenses/by-sa/2.0)
- Change: Wikimedia-generated thumbnail; no local image edits.
