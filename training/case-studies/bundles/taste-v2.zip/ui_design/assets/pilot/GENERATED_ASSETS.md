# Generated pilot assets

Eight standalone 1536 × 1024 landscape concept images, generated October 20, 2026 with the built-in image_gen tool. These are the active images for the eight asset-backed pilot briefs. Every comparison arm receives the same frozen files. The other 16 briefs remain image-free.

The original Wikimedia images and their attribution records are preserved as a separate reference set. Generated images are explicitly labeled as generated; they do not inherit the Wikimedia licenses or the fictional dataset CC0 dedication. No source photographs were passed to the generator. Exact prompts and SHA-256 hashes are recorded in [generated-prompts-v1.json](generated-prompts-v1.json).

These images contain no page layout or embedded copy: selecting, cropping, placing, and integrating them remains the task of the page-generating model. Changes to the asset set require new runs; do not pool results from public-v1 and generated-v1 as if inputs were identical.

## ramen-counter

Tonkotsu ramen in handmade ceramic on a warm railway-arch counter.

![Tonkotsu ramen in handmade ceramic on a warm railway-arch counter.](ramen-counter-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. An editorial food photograph for a fictional twelve-seat ramen counter inside a railway arch. A single handmade dark ceramic bowl of creamy tonkotsu ramen, carefully arranged noodles, pork slices, egg and scallions on a worn wooden counter. Soft steam in warm sidelight, textured brick softly out of focus, confident restrained styling, inviting and appetizing. No people, no packaging. Bowl fully within frame with breathing room. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## bakery-subscription

Rustic sourdough loaf and cut slice in soft morning window light.

![Rustic sourdough loaf and cut slice in soft morning window light.](bakery-subscription-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. Art-directed bakery photograph for a fictional sourdough subscription. One rustic round sourdough loaf with beautiful natural scoring and one cut slice showing airy crumb, on flour-dusted warm wood beside a folded natural linen cloth. Gentle early morning window light, tactile crust, warm neutral colors, understated artisanal quality. No fake flour explosion, no hands, no packaging. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## dog-daycare

Two dogs playing on a grassy farm paddock with a barn behind them.

![Two dogs playing on a grassy farm paddock with a barn behind them.](dog-daycare-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. Premium natural editorial photograph for a fictional farm dog daycare. Two healthy happy dogs, one golden retriever and one smaller mixed-breed dog, playing together in a spacious grassy paddock, rustic barn and trees softly blurred behind them. Eye-level camera, natural movement and anatomically correct paws, soft morning light, reassuring outdoorsy atmosphere, uncluttered composition. No humans, no collars with text, no urban landmarks. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## museum-exhibition

Mid-century modern house scale model displayed in a quiet gallery.

![Mid-century modern house scale model displayed in a quiet gallery.](museum-exhibition-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. Sophisticated museum editorial photograph for a fictional architectural-model exhibition. A carefully crafted mid-century modern house scale model in pale wood, white card and clear acrylic, displayed on a simple light plinth; clean roof planes, transparent windows, subtle interior detail. Gallery background with softly blurred architectural drawings, no legible text. Beautiful museum side lighting, quiet shadows, refined restrained composition. Clearly an architectural scale model, not a full-size building. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## plant-shop

Monstera and pothos in terracotta and ceramic pots against warm plaster.

![Monstera and pothos in terracotta and ceramic pots against warm plaster.](plant-shop-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. Beautiful botanical editorial photograph for a fictional houseplant shop. A healthy monstera deliciosa plant with several lush naturally fenestrated leaves in a simple unbranded terracotta pot, beside a smaller pothos in a cream ceramic pot. Soft daylight across a warm off-white plaster wall and stone ledge, subtle natural shadows, vivid but believable greens. Entire pots visible, uncluttered composition with useful breathing room. No fake plants, no botanical labels. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## coffee-roaster

Roasted beans and black filter coffee in handmade ceramics on oak.

![Roasted beans and black filter coffee in handmade ceramics on oak.](coffee-roaster-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. Premium restrained coffee editorial still life for a fictional independent roaster. A small shallow ceramic dish of freshly roasted medium-brown coffee beans next to one simple cream cup of black filter coffee on warm oak. Some beans scattered sparingly, tactile textures, gentle directional morning light, balanced composition, warm specific artisanal mood. No latte art, no packaging, no logos, no text. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## furniture-maker

Oak bench and ash side table in a quiet naturally lit room.

![Oak bench and ash side table in a quiet naturally lit room.](furniture-maker-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. High-end furniture editorial photograph for a fictional small wood workshop catalogue. A beautifully crafted simple solid oak bench with clean joinery and an ash side table, in a quiet light-plaster room with warm daylight. Natural wood grain and believable proportions, understated contemporary craftsmanship, no upholstery, no ornament, no shop windows or reflections. Objects fully within frame and useful surrounding space. Calm material-focused editorial photography. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.

## community-garden

Raised vegetable beds, gravel path and wooden shed in an urban garden.

![Raised vegetable beds, gravel path and wooden shed in an urban garden.](community-garden-generated-v1.png)

**Generation prompt**

Use case: photorealistic-natural. Asset type: reusable website photography, one standalone landscape image in approximately 3:2 ratio. Warm natural editorial photograph for a fictional urban community garden. Well-tended raised beds with leafy vegetables, a simple gravel path, wooden tool shed and modest city buildings softly visible behind trees. Gentle morning sunlight, hopeful welcoming handmade character, rich natural greens, thoughtful photographic composition. No people, no readable signs, no cartoon vegetables, no implausible giant produce. This is image material for a web-design benchmark, not a screenshot or page mockup. No text, lettering, watermarks, borders, collage, UI, or embedded graphic design. Polished but plausible photography. Keep the key subject in the central area so both wide and narrower crops are usable.
